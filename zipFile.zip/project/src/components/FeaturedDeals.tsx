import { Flame, ShoppingCart, Instagram, Send } from 'lucide-react';

const INSTAGRAM_URL = 'https://www.instagram.com/jhojha.games?igsh=ZGltczl3MHh0ZTN1';
const TELEGRAM_URL = 'https://t.me/jhojhagames';

const deals = [
  {
    id: 1,
    title: 'GTA VI Pre-Order Standard Edition',
    image: 'https://images.unsplash.com/photo-1605379399128-3c0f1f5a9f5e?auto=compress&cs=tinysrgb&w=800',
    salePrice: 279,
    originalPrice: 3299,
    badge: 'SALE',
    badgeClass: 'badge-sale',
  },
  {
    id: 2,
    title: "Assassin's Creed Black Flag Resynced",
    image: 'https://images.unsplash.com/photo-1538481190585-7f09b1dc1b48?auto=compress&cs=tinysrgb&w=800',
    salePrice: 799,
    originalPrice: 4999,
    badge: 'SALE',
    badgeClass: 'badge-sale',
  },
  {
    id: 3,
    title: 'Outlast Trials',
    image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=compress&cs=tinysrgb&w=800',
    salePrice: 499,
    originalPrice: 2449,
    badge: 'HOT DEAL',
    badgeClass: 'badge-new',
  },
  {
    id: 4,
    title: 'Resident Evil Requiem',
    image: 'https://images.unsplash.com/photo-1607437178511-4f3c1c1f1f1f?auto=compress&cs=tinysrgb&w=800',
    salePrice: 499,
    originalPrice: 4999,
    badge: 'BEST SELLER',
    badgeClass: 'badge-new',
  },
  {
    id: 5,
    title: "Assassin's Creed Black Flag Resynced",
    image: 'https://images.unsplash.com/photo-1556438064-2d7646166914?auto=compress&cs=tinysrgb&w=800',
    salePrice: 299,
    originalPrice: 1999,
    badge: 'PRE-ORDER',
    badgeClass: 'badge-new',
  },
  {
    id: 6,
    title: 'Forza Horizon Series',
    image: 'https://images.unsplash.com/photo-1503376780353-7e9729b2c1c4?auto=compress&cs=tinysrgb&w=800',
    salePrice: 349,
    originalPrice: 1999,
    badge: 'SALE',
    badgeClass: 'badge-sale',
  },
];

export default function FeaturedDeals() {
  return (
    <section id="featured-deals" className="relative py-16 lg:py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-yellow-500/5 to-transparent" />
      <div className="absolute top-0 left-0 w-72 h-72 bg-red-500/5 rounded-full blur-3xl" />
      <div className="absolute bottom-0 right-0 w-72 h-72 bg-yellow-500/5 rounded-full blur-3xl" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-red-500/40 bg-red-500/10 mb-4">
            <Flame className="w-3.5 h-3.5 text-red-500 fill-red-500" />
            <span className="text-red-400 text-xs font-rajdhani font-700 uppercase tracking-widest">
              Featured Gaming Deals
            </span>
          </div>
          <h2 className="font-orbitron text-2xl sm:text-3xl lg:text-4xl font-black mb-3">
            <span className="text-yellow-500 gold-glow">🔥 Featured </span>
            <span className="text-white">Gaming </span>
            <span className="text-yellow-500 gold-glow">Deals 🔥</span>
          </h2>
          <p className="text-gray-400 font-rajdhani text-base sm:text-lg uppercase tracking-wider">
            Premium PC Games At Affordable Prices
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 lg:gap-6">
          {deals.map((deal, idx) => (
            <div
              key={deal.id}
              className="deal-card group relative rounded-2xl overflow-hidden bg-gradient-to-b from-[#1A1A1A] to-[#0F0F0F] border border-yellow-500/15 shimmer-sweep"
              style={{ animation: `fadeInUp 0.6s ease ${idx * 0.1}s both` }}
            >
              {/* Image */}
              <div className="relative h-48 sm:h-52 overflow-hidden">
                <img
                  src={deal.image}
                  alt={deal.title}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-black/50 to-transparent" />

                {/* Badge */}
                <div className="absolute top-3 left-3">
                  <div className="relative">
                    <div className="absolute inset-0 bg-yellow-500 blur-lg opacity-40" />
                    <span className={`relative ${deal.badgeClass} px-3 py-1.5 rounded-lg font-rajdhani text-xs font-700 uppercase tracking-wider`}>
                      {deal.badge}
                    </span>
                  </div>
                </div>
              </div>

              {/* Content */}
              <div className="p-5">
                <h3 className="font-rajdhani text-lg font-700 text-white group-hover:text-yellow-500 transition-colors duration-300 mb-3 line-clamp-2 min-h-[3.5rem]">
                  {deal.title}
                </h3>

                <div className="flex items-center gap-3 mb-4">
                  <span className="font-orbitron text-2xl font-black text-yellow-500 drop-shadow-[0_0_8px_rgba(245,166,35,0.5)]">
                    ₹{deal.salePrice}
                  </span>
                  <span className="text-sm text-gray-500 line-through font-inter">
                    ₹{deal.originalPrice}
                  </span>
                </div>

                {/* Action buttons */}
                <div className="space-y-2">
                  <a
                    href={`${TELEGRAM_URL}?text=I%20want%20to%20order%20${encodeURIComponent(deal.title)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="order-btn w-full py-3 rounded-lg font-rajdhani text-sm font-700 uppercase tracking-widest flex items-center justify-center gap-2"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    Order Now
                  </a>

                  <div className="grid grid-cols-2 gap-2">
                    <a
                      href={`${INSTAGRAM_URL}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-2.5 rounded-lg bg-gradient-to-r from-purple-600 via-pink-500 to-yellow-500 text-white font-rajdhani text-xs font-700 uppercase tracking-wider flex items-center justify-center gap-1.5 hover:shadow-[0_0_20px_rgba(245,166,35,0.4)] hover:-translate-y-0.5 transition-all duration-300"
                    >
                      <Instagram className="w-3.5 h-3.5" />
                      Instagram
                    </a>
                    <a
                      href={`${TELEGRAM_URL}?text=I%20want%20to%20order%20${encodeURIComponent(deal.title)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="py-2.5 rounded-lg bg-gradient-to-r from-blue-500 to-blue-600 text-white font-rajdhani text-xs font-700 uppercase tracking-wider flex items-center justify-center gap-1.5 hover:shadow-[0_0_20px_rgba(59,130,246,0.4)] hover:-translate-y-0.5 transition-all duration-300"
                    >
                      <Send className="w-3.5 h-3.5" />
                      Telegram
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
